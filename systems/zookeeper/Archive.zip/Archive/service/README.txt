Files required by scripts to run the service go here

Examples include dockerfiles.
